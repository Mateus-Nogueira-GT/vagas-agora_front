# Código Atualizado: Checkboxes de Nível de Experiência

## Localização
Arquivo: `app/candidato/pesquisar-vagas/page.tsx`
Aproximadamente linhas 783-850

## Substituir por:

```tsx
{/* Nível de experiência */}
<div>
  <Label className="text-sm text-gray-600 mb-2 block">Nível de experiência</Label>
  <div className="space-y-2">
    <div className="flex items-center space-x-2">
      <Checkbox
        id="estagio"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.estagio}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            estagio: !!checked
          }
        }))}
      />
      <Label htmlFor="estagio" className="text-sm text-gray-700">
        Estágio / Trainee
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="assistente"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.assistente}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            assistente: !!checked
          }
        }))}
      />
      <Label htmlFor="assistente" className="text-sm text-gray-700">
        Assistente / Auxiliar
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="operacional"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.operacional}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            operacional: !!checked
          }
        }))}
      />
      <Label htmlFor="operacional" className="text-sm text-gray-700">
        Operacional
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="analista"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.analista}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            analista: !!checked
          }
        }))}
      />
      <Label htmlFor="analista" className="text-sm text-gray-700">
        Analista
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="coordenacao"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.coordenacao}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            coordenacao: !!checked
          }
        }))}
      />
      <Label htmlFor="coordenacao" className="text-sm text-gray-700">
        Coordenação
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="gerencia"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.gerencia}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            gerencia: !!checked
          }
        }))}
      />
      <Label htmlFor="gerencia" className="text-sm text-gray-700">
        Gerência
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="diretoria"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.diretoria}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            diretoria: !!checked
          }
        }))}
      />
      <Label htmlFor="diretoria" className="text-sm text-gray-700">
        Diretoria
      </Label>
    </div>
    <div className="flex items-center space-x-2">
      <Checkbox
        id="especialista"
        className="border-[#4400CC]/50 data-[state=checked]:bg-[#4400CC] data-[state=checked]:text-white"
        checked={sidebarFilters.nivel_experiencia.especialista}
        onCheckedChange={(checked) => setSidebarFilters(prev => ({
          ...prev,
          nivel_experiencia: {
            ...prev.nivel_experiencia,
            especialista: !!checked
          }
        }))}
      />
      <Label htmlFor="especialista" className="text-sm text-gray-700">
        Especialista
      </Label>
    </div>
  </div>
</div>
```

## Passos para aplicar:

1. Abrir `app/candidato/pesquisar-vagas/page.tsx`
2. Procurar por `{/* Nível de experiência */}`
3. Selecionar toda a seção até o fechamento `</div>`
4. Substituir pelo código acima
5. Salvar

## Nota Importante:
Certifique-se de que o estado `nivel_experiencia` já foi atualizado (deve estar com os novos valores: estagio, assistente, operacional, analista, coordenacao, gerencia, diretoria, especialista).
