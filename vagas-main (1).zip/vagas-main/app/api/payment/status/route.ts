import { NextRequest, NextResponse } from 'next/server'
import { paymentService } from '@/lib/payment/payment-service'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId é obrigatório' },
        { status: 400 }
      )
    }

    const result = await paymentService.getUserSubscriptionStatus(userId)

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Erro ao verificar status' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      isActive: result.isActive || false,
      subscription: result.subscription || null
    })

  } catch (error) {
    console.error('Erro na API de status de pagamento:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
