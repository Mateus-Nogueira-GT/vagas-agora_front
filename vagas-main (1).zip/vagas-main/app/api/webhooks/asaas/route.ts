import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'
import crypto from 'crypto'

// Função para verificar assinatura do webhook
function verifyWebhookSignature(rawBody: string, signature: string | null): boolean {
  const webhookSecret = process.env.ASAAS_WEBHOOK_SECRET
  
  // Se não tem secret configurado, aceita (para desenvolvimento)
  // Em produção, SEMPRE configure o secret!
  if (!webhookSecret) {
    console.warn('[ASAAS WEBHOOK] ⚠️ ASAAS_WEBHOOK_SECRET não configurado - verificação desabilitada')
    return true
  }
  
  if (!signature) {
    return false
  }
  
  const expectedSignature = crypto
    .createHmac('sha256', webhookSecret)
    .update(rawBody)
    .digest('hex')
  
  try {
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    )
  } catch {
    return false
  }
}

// Webhook ÚNICO do Asaas para receber notificações de PAGAMENTOS e ASSINATURAS
export async function POST(request: NextRequest) {
  try {
    // 1. Pegar o corpo como texto para verificação
    const rawBody = await request.text()
    
    // 2. Verificar assinatura do webhook
    const signature = request.headers.get('asaas-access-token') ||
                     request.headers.get('x-asaas-signature')
    
    if (!verifyWebhookSignature(rawBody, signature)) {
      console.error('[ASAAS WEBHOOK] ❌ Assinatura inválida')
      return NextResponse.json(
        { error: 'Assinatura de webhook inválida' },
        { status: 403 }
      )
    }
    
    // 3. Parsear o body após verificação
    const body = JSON.parse(rawBody)


    const { event, payment, subscription } = body

    // Validar que o evento existe
    if (!event) {
      console.error('[ASAAS WEBHOOK] ❌ Evento não informado no payload')
      return NextResponse.json({ error: 'Event is required' }, { status: 400 })
    }

    // ========================================
    // EVENTOS DE PAGAMENTO (PAYMENT_*)
    // ========================================

    if (event === 'PAYMENT_RECEIVED' || event === 'PAYMENT_CONFIRMED') {
      // Pagamento confirmado! Ativar verificação do currículo

      // Buscar a assinatura relacionada a este pagamento
      const { data: dbSubscription, error: subError } = await supabase
        .from('asaas_subscriptions')
        .select('*')
        .eq('asaas_subscription_id', payment.subscription)
        .maybeSingle()

      if (subError) {
        console.error('[ASAAS WEBHOOK] Erro ao buscar assinatura:', subError)
        return NextResponse.json({ error: 'Database error' }, { status: 500 })
      }

      if (!dbSubscription) {
        console.error('[ASAAS WEBHOOK] ⚠️ Assinatura não encontrada:', payment.subscription)
        return NextResponse.json({ error: 'Subscription not found' }, { status: 404 })
      }

      // Atualizar status da assinatura para ACTIVE e ativar verificação
      const { error: updateError } = await supabase
        .from('asaas_subscriptions')
        .update({
          status: 'ACTIVE',
          verification_active: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', dbSubscription.id)

      if (updateError) {
        console.error('[ASAAS WEBHOOK] Erro ao atualizar assinatura:', updateError)
        return NextResponse.json({ error: 'Failed to update subscription' }, { status: 500 })
      }


      // Atualizar ou inserir o pagamento na tabela asaas_payments
      const { data: existingPayment } = await supabase
        .from('asaas_payments')
        .select('id')
        .eq('asaas_payment_id', payment.id)
        .maybeSingle()

      if (existingPayment) {
        // Atualizar pagamento existente
        const { error: updatePaymentError } = await supabase
          .from('asaas_payments')
          .update({
            status: payment.status,
            payment_date: payment.paymentDate || payment.clientPaymentDate,
            net_value: payment.netValue,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingPayment.id)

        if (updatePaymentError) {
          console.error('[ASAAS WEBHOOK] Erro ao atualizar pagamento:', updatePaymentError)
        } else {
        }
      } else {
        // Inserir novo pagamento
        const { error: insertPaymentError } = await supabase
          .from('asaas_payments')
          .insert({
            subscription_id: dbSubscription.id,
            asaas_payment_id: payment.id,
            billing_type: payment.billingType,
            value: payment.value,
            net_value: payment.netValue,
            original_value: payment.originalValue,
            status: payment.status,
            due_date: payment.dueDate,
            payment_date: payment.paymentDate || payment.clientPaymentDate,
            invoice_url: payment.invoiceUrl,
            bank_slip_url: payment.bankSlipUrl,
            transaction_receipt_url: payment.transactionReceiptUrl,
            description: payment.description
          })

        if (insertPaymentError) {
          console.error('[ASAAS WEBHOOK] Erro ao inserir pagamento:', insertPaymentError)
        } else {
        }
      }


      return NextResponse.json({
        success: true,
        message: 'Payment confirmed and subscription activated'
      })
    }

    if (event === 'PAYMENT_OVERDUE') {
      // Pagamento vencido - desativar verificação

      const { data: dbSubscription } = await supabase
        .from('asaas_subscriptions')
        .select('*')
        .eq('asaas_subscription_id', payment.subscription)
        .maybeSingle()

      if (dbSubscription) {
        await supabase
          .from('asaas_subscriptions')
          .update({
            status: 'OVERDUE',
            verification_active: false,
            updated_at: new Date().toISOString()
          })
          .eq('id', dbSubscription.id)

        // Atualizar status do pagamento
        await supabase
          .from('asaas_payments')
          .update({
            status: 'OVERDUE',
            updated_at: new Date().toISOString()
          })
          .eq('asaas_payment_id', payment.id)

      }

      return NextResponse.json({ success: true, message: 'Payment overdue processed' })
    }

    if (event === 'PAYMENT_UPDATED') {

      // Atualizar dados do pagamento
      await supabase
        .from('asaas_payments')
        .update({
          status: payment.status,
          value: payment.value,
          net_value: payment.netValue,
          payment_date: payment.paymentDate || payment.clientPaymentDate,
          updated_at: new Date().toISOString()
        })
        .eq('asaas_payment_id', payment.id)

      return NextResponse.json({ success: true, message: 'Payment updated' })
    }

    // ========================================
    // EVENTOS DE ASSINATURA (SUBSCRIPTION_*)
    // ========================================

    if (event === 'SUBSCRIPTION_CREATED') {
      return NextResponse.json({ success: true, message: 'Subscription created event received' })
    }

    if (event === 'SUBSCRIPTION_UPDATED') {

      await supabase
        .from('asaas_subscriptions')
        .update({
          status: subscription.status === 'ACTIVE' ? 'ACTIVE' : 'INACTIVE',
          value: subscription.value,
          next_due_date: subscription.nextDueDate,
          updated_at: new Date().toISOString()
        })
        .eq('asaas_subscription_id', subscription.id)

      return NextResponse.json({ success: true, message: 'Subscription updated' })
    }

    if (event === 'SUBSCRIPTION_DELETED') {

      await supabase
        .from('asaas_subscriptions')
        .update({
          status: 'INACTIVE',
          verification_active: false,
          updated_at: new Date().toISOString()
        })
        .eq('asaas_subscription_id', subscription.id)


      return NextResponse.json({ success: true, message: 'Subscription deleted' })
    }

    // ========================================
    // EVENTOS NÃO TRATADOS
    // ========================================


    return NextResponse.json({
      success: true,
      message: 'Event received but not handled',
      event
    })

  } catch (error) {
    console.error('[ASAAS WEBHOOK] ❌ Erro ao processar webhook:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Permitir GET para teste
export async function GET() {
  return NextResponse.json({
    message: 'Asaas Webhook endpoint is working',
    endpoint: '/api/webhooks/asaas',
    timestamp: new Date().toISOString(),
    events_handled: [
      'PAYMENT_RECEIVED',
      'PAYMENT_CONFIRMED',
      'PAYMENT_OVERDUE',
      'PAYMENT_UPDATED',
      'SUBSCRIPTION_CREATED',
      'SUBSCRIPTION_UPDATED',
      'SUBSCRIPTION_DELETED'
    ]
  })
}
