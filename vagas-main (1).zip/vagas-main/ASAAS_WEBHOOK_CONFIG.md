# Configuração do Webhook Asaas

## URL do Webhook

Configure no painel do Asaas a seguinte URL:

```
https://vagas-dok.agio.dev/api/webhooks/asaas
```

## Passos para Configurar no Asaas

1. Acesse o painel do Asaas: https://www.asaas.com/
2. Vá em **Configurações** → **Integrações** → **Webhooks**
3. Clique em **Novo Webhook** ou **Configurar Webhook**
4. Cole a URL: `https://vagas-dok.agio.dev/api/webhooks/asaas`
5. Selecione os seguintes eventos:
   - ✅ **PAYMENT_RECEIVED** (Pagamento recebido via PIX/Boleto)
   - ✅ **PAYMENT_CONFIRMED** (Pagamento confirmado via Cartão)
   - ✅ **PAYMENT_OVERDUE** (Pagamento vencido)
   - ✅ **PAYMENT_DELETED** (Opcional)
   - ✅ **PAYMENT_RESTORED** (Opcional)
6. Salve a configuração

## Ambiente Sandbox (Teste)

Para o ambiente de homologação/sandbox, use a mesma URL:
```
https://vagas-dok.agio.dev/api/webhooks/asaas
```

O Asaas Sandbox enviará notificações de teste para esta URL.

## Como Testar

1. **Teste Manual via Browser:**
   - Acesse: `https://vagas-dok.agio.dev/api/webhooks/asaas`
   - Deve retornar: `{"message": "Asaas Webhook endpoint is working", "timestamp": "..."}`

2. **Teste via Asaas Dashboard:**
   - No painel de Webhooks do Asaas, há um botão "Testar Webhook"
   - Clique e verifique se o Asaas consegue alcançar sua URL
   - Status 200 = OK

3. **Teste Real:**
   - Crie uma assinatura de teste
   - Faça um pagamento de teste (PIX/Boleto)
   - O webhook será chamado automaticamente
   - Verifique os logs do servidor: `[ASAAS WEBHOOK] ...`

## Fluxo de Funcionamento

1. **Cliente clica em "Pagar R$ 19,90"**
   - Sistema cria assinatura no Asaas
   - Status inicial: `PENDING`
   - `verification_active`: `false`

2. **Cliente paga (PIX/Boleto/Cartão)**
   - Asaas detecta o pagamento
   - Asaas envia webhook: `PAYMENT_RECEIVED` ou `PAYMENT_CONFIRMED`

3. **Seu servidor recebe o webhook**
   - Atualiza assinatura: `status = ACTIVE`
   - Ativa verificação: `verification_active = true`
   - Registra pagamento na tabela `asaas_payments`

4. **Cliente tem verificação ativa**
   - Badge de verificado aparece
   - Currículo em destaque nas buscas
   - Válido por 1 ano

## Estrutura do Payload do Webhook

```json
{
  "event": "PAYMENT_RECEIVED",
  "payment": {
    "id": "pay_xxxxx",
    "subscription": "sub_xxxxx",
    "customer": "cus_xxxxx",
    "billingType": "PIX",
    "value": 19.90,
    "netValue": 18.50,
    "status": "RECEIVED",
    "dueDate": "2025-01-30",
    "paymentDate": "2025-01-30",
    "invoiceUrl": "https://...",
    "bankSlipUrl": null,
    "transactionReceiptUrl": "https://..."
  }
}
```

## Eventos Importantes

- **PAYMENT_RECEIVED**: PIX ou Boleto foi pago ✅
- **PAYMENT_CONFIRMED**: Cartão de crédito foi aprovado ✅
- **PAYMENT_OVERDUE**: Pagamento venceu sem ser pago ⚠️
- **PAYMENT_REFUNDED**: Pagamento foi estornado ⚠️

## Segurança

⚠️ **IMPORTANTE**: Por segurança, você deve validar que o webhook realmente veio do Asaas.

Opções:
1. **IP Whitelist**: Aceitar apenas IPs do Asaas
2. **Token de Autenticação**: Asaas envia um token no header
3. **Validação de Signature**: Validar assinatura HMAC

Consulte a documentação do Asaas para implementar validação adicional.

## Logs e Debugging

Para ver os logs do webhook:
```bash
# Se estiver usando PM2 ou similar
pm2 logs

# Ou verifique os logs do Next.js
# Todos os webhooks são logados com prefixo [ASAAS WEBHOOK]
```

## Troubleshooting

**Webhook não está sendo chamado?**
- ✅ Verifique se a URL está correta no painel Asaas
- ✅ Teste manualmente: `curl https://vagas-dok.agio.dev/api/webhooks/asaas`
- ✅ Verifique se seu servidor está online e acessível
- ✅ Veja os logs de erro no painel do Asaas

**Pagamento foi recebido mas assinatura não ativou?**
- ✅ Verifique os logs: `[ASAAS WEBHOOK]`
- ✅ Confirme que o `payment.subscription` corresponde ao `asaas_subscription_id`
- ✅ Verifique se não há erros de banco de dados nos logs