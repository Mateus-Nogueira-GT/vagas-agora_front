"use client"

import React from "react"
import { usePathname } from "next/navigation"
import dynamic from "next/dynamic"

const Sidebar = dynamic(() => import("@/components/sidebar"), { ssr: false })
const MainContent = dynamic(() => import("@/components/main-content").then(mod => ({ default: mod.MainContent })), { ssr: false })
const EmployerMobileHeader = dynamic(() => import("@/components/employer-mobile-header"), { ssr: false })
const CandidateMobileHeader = dynamic(() => import("@/components/candidate-mobile-header"), { ssr: false })
const SidebarProvider = dynamic(() => import("@/contexts/sidebar-context").then(mod => ({ default: mod.SidebarProvider })), { ssr: false })
const ViewProvider = dynamic(() => import("@/contexts/view-context").then(mod => ({ default: mod.ViewProvider })), { ssr: false })

export default function ConditionalLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()

  // Rotas que não devem ter sidebar
  const routesWithoutSidebar = ["/login", "/cadastro", "/forgot-password"]
  const shouldHideSidebar = routesWithoutSidebar.some(route => pathname?.startsWith(route))

  // Verificar se está na área de empregador ou candidato
  const isEmployerRoute = pathname?.startsWith('/empregador')
  const isCandidateRoute = pathname?.startsWith('/candidato')

  if (shouldHideSidebar) {
    return <>{children}</>
  }

  return (
    <ViewProvider>
      <SidebarProvider>
        <div className="flex min-h-screen">
          <Sidebar />
          {/* Header mobile para rotas de empregador e candidato */}
          {isEmployerRoute && <EmployerMobileHeader />}
          {isCandidateRoute && <CandidateMobileHeader />}
          <MainContent>{children}</MainContent>
        </div>
      </SidebarProvider>
    </ViewProvider>
  )
}
