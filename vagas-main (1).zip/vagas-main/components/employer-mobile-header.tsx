"use client"

import { useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import {
  Home,
  Briefcase,
  FileBarChart,
  CreditCard,
  HelpCircle,
  Settings,
  LogOut,
  Menu,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useAuth } from "@/hooks/use-auth"
import { useEmpresas } from "@/hooks/use-empresas"
import { useEffect } from "react"
import Image from "next/image"
import { Building } from "lucide-react"

export default function EmployerMobileHeader() {
  const router = useRouter()
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const { currentEmpresa, loadCurrentEmpresa } = useEmpresas()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Carregar dados da empresa
  useEffect(() => {
    if (user?.id && user?.role === 'empregador') {
      loadCurrentEmpresa().catch(err => {
        console.error('[MOBILE HEADER] Erro ao carregar dados da empresa:', err)
      })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.role])

  // Navigation items for employer
  const employerNavItems = [
    { name: "Início", href: "/empregador", icon: Home },
    { name: "Gerenciar Vagas", href: "/empregador/vagas", icon: Briefcase },
    { name: "Relatórios", href: "/empregador/dashboard", icon: FileBarChart },
    { name: "Assinatura", href: "/empregador/assinatura", icon: CreditCard },
  ]

  // Footer items
  const footerItems = [
    { name: "Ajuda", href: "/empregador/ajuda", icon: HelpCircle },
    { name: "Configurações", href: "/empregador/configuracoes", icon: Settings },
  ]

  // Função para navegar
  const handleNavigation = (href: string) => {
    try {
      router.push(href)
      setIsMenuOpen(false) // Fecha o menu após navegar
    } catch (error) {
      console.error("Erro ao navegar:", error)
      window.location.href = href
    }
  }

  // Função para verificar se um item está ativo
  const isItemActive = (itemHref: string) => {
    if (pathname === itemHref) {
      return true
    }

    if (itemHref === "/empregador" && pathname === "/empregador") {
      return true
    }

    if (itemHref !== "/" &&
        itemHref !== "/empregador" &&
        pathname?.startsWith(itemHref + "/")) {
      return true
    }

    return false
  }

  // Função para handle do logout
  const handleLogout = () => {
    setIsMenuOpen(false)
    logout()
  }

  return (
    <>
      {/* Header fixo no topo */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-[#4400CC]/20 shadow-lg z-50 flex items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-Vagas-Agora-kCs5jK59J2lfCgIXjngzVmXNfhi9tz.png"
            alt="Vagas Agora"
            className="h-6 w-auto"
          />
        </div>

        {/* Botão do menu hamburguer */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="p-2 rounded-lg hover:bg-[#4400CC]/10 transition-colors"
          aria-label="Menu"
        >
          {isMenuOpen ? (
            <X size={24} className="text-[#4400CC]" />
          ) : (
            <Menu size={24} className="text-[#4400CC]" />
          )}
        </button>
      </header>

      {/* Menu lateral que desliza da direita */}
      <div
        className={cn(
          "lg:hidden fixed top-16 right-0 bottom-0 w-64 bg-white border-l border-[#4400CC]/20 shadow-2xl z-40 transform transition-transform duration-300 ease-in-out overflow-y-auto",
          isMenuOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        {/* Perfil da empresa */}
        <div className="p-4 border-b border-[#4400CC]/20">
          <div className="flex items-center">
            <div className="relative">
              <div className="w-12 h-12 rounded-full bg-[#00FFAE] flex items-center justify-center text-[#4400CC] shadow-[0_0_10px_rgba(0,255,174,0.3)] overflow-hidden">
                {currentEmpresa?.logo_url ? (
                  <Image
                    src={currentEmpresa.logo_url}
                    alt="Logo da empresa"
                    width={48}
                    height={48}
                    className="w-full h-full object-cover"
                    unoptimized
                  />
                ) : (
                  <Building size={24} />
                )}
              </div>
            </div>
            <div className="ml-3 flex-1 min-w-0">
              <p className="font-medium text-sm text-gray-800 truncate">
                {currentEmpresa?.nome || user?.nome || user?.email?.split('@')[0] || 'Empresa'}
              </p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
        </div>

        {/* Navegação principal */}
        <nav className="py-4">
          <ul className="space-y-2 px-3">
            {employerNavItems.map((item) => (
              <li key={item.name}>
                <button
                  role="link"
                  aria-label={`Navegar para ${item.name}`}
                  className={cn(
                    "w-full flex items-center py-3 px-3 rounded-lg transition-all text-left",
                    isItemActive(item.href)
                      ? "bg-[#00FFAE] text-[#4400CC] font-medium shadow-[0_0_10px_rgba(0,255,174,0.3)]"
                      : "hover:bg-[#00FFAE]/10 hover:text-[#4400CC]",
                  )}
                  onClick={() => handleNavigation(item.href)}
                >
                  <item.icon size={20} className={isItemActive(item.href) ? "text-[#4400CC]" : "text-gray-600"} />
                  <span className="ml-3">{item.name}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Footer com configurações e logout */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-[#4400CC]/20 bg-white">
          <ul className="space-y-2 px-3 py-4">
            {footerItems.map((item) => (
              <li key={item.name}>
                <button
                  role="link"
                  aria-label={`Navegar para ${item.name}`}
                  className={cn(
                    "w-full flex items-center py-3 px-3 rounded-lg transition-all text-left",
                    isItemActive(item.href)
                      ? "bg-[#00FFAE] text-[#4400CC] font-medium shadow-[0_0_10px_rgba(0,255,174,0.3)]"
                      : "hover:bg-[#00FFAE]/10 hover:text-[#4400CC]",
                  )}
                  onClick={() => handleNavigation(item.href)}
                >
                  <item.icon size={20} className={isItemActive(item.href) ? "text-[#4400CC]" : "text-gray-600"} />
                  <span className="ml-3">{item.name}</span>
                </button>
              </li>
            ))}

            {/* Botão de Logout */}
            <li>
              <button
                aria-label="Sair da conta"
                className="w-full flex items-center py-3 px-3 rounded-lg transition-all text-left hover:bg-red-50 hover:text-red-600"
                onClick={handleLogout}
              >
                <LogOut size={20} className="text-gray-600 hover:text-red-600" />
                <span className="ml-3">Sair</span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Overlay escuro quando o menu está aberto */}
      {isMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30 top-16"
          onClick={() => setIsMenuOpen(false)}
        />
      )}
    </>
  )
}
