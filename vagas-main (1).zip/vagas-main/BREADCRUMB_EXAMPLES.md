# Exemplos de Integração de Breadcrumbs

## Como adicionar breadcrumbs em páginas existentes

### 1. Dashboard do Candidato (app/candidato/dashboard/page.tsx)

**Adicionar import no topo:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**Adicionar no JSX, logo após o ProtectedRoute wrapper e antes do conteúdo principal:**
```tsx
<ProtectedRoute requiredRole="candidato">
  <div className="min-h-screen bg-gray-50">
    {/* Adicionar breadcrumb aqui */}
    <div className="px-6 md:px-10 pt-6">
      <Breadcrumb items={candidatoBreadcrumbs.dashboard} />
    </div>

    {/* Resto do conteúdo */}
    <div className="px-6 md:px-10 py-8">
      {/* ... conteúdo existente ... */}
    </div>
  </div>
</ProtectedRoute>
```

### 2. Pesquisar Vagas (app/candidato/pesquisar-vagas/page.tsx)

**Import:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**No JSX:**
```tsx
<div className="min-h-screen bg-gray-50">
  <div className="px-6 md:px-10 pt-6">
    <Breadcrumb items={candidatoBreadcrumbs.pesquisarVagas} />
  </div>

  {/* Resto do conteúdo */}
</div>
```

### 3. Detalhes da Vaga (app/candidato/pesquisar-vagas/[id]/page.tsx)

**Import:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**No JSX (após carregar os dados da vaga):**
```tsx
<div className="min-h-screen bg-gray-50">
  <div className="px-6 md:px-10 pt-6">
    <Breadcrumb items={candidatoBreadcrumbs.detalhesVaga(vaga?.titulo)} />
  </div>

  {/* Resto do conteúdo */}
</div>
```

### 4. Candidaturas (app/candidato/candidaturas/page.tsx)

**Import:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**No JSX:**
```tsx
<div className="min-h-screen bg-gray-50">
  <div className="px-6 md:px-10 pt-6">
    <Breadcrumb items={candidatoBreadcrumbs.candidaturas} />
  </div>

  {/* Resto do conteúdo */}
</div>
```

### 5. Configurações (app/candidato/configuracoes/page.tsx)

**Import:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**No JSX:**
```tsx
<div className="min-h-screen bg-gray-50">
  <div className="px-6 md:px-10 pt-6">
    <Breadcrumb items={candidatoBreadcrumbs.configuracoes} />
  </div>

  {/* Resto do conteúdo */}
</div>
```

### 6. Ajuda (app/candidato/ajuda/page.tsx)

**Import:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**No JSX:**
```tsx
<div className="min-h-screen bg-gray-50">
  <div className="px-6 md:px-10 pt-6">
    <Breadcrumb items={candidatoBreadcrumbs.ajuda} />
  </div>

  {/* Resto do conteúdo */}
</div>
```

### 7. Verificar Currículo (app/candidato/curriculo/verificar/page.tsx)

**Import:**
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

**No JSX:**
```tsx
<div className="min-h-screen bg-gray-50">
  <div className="px-6 md:px-10 pt-6">
    <Breadcrumb items={candidatoBreadcrumbs.curriculoVerificar} />
  </div>

  {/* Resto do conteúdo */}
</div>
```

## Padrão de Layout Recomendado

Para manter consistência, use este padrão em todas as páginas:

```tsx
export default function Page() {
  return (
    <ProtectedRoute requiredRole="candidato">
      <div className="min-h-screen bg-gray-50">
        {/* Container do Breadcrumb - sempre primeiro */}
        <div className="px-6 md:px-10 pt-6">
          <Breadcrumb items={candidatoBreadcrumbs.nomeDaPagina} />
        </div>

        {/* Conteúdo principal */}
        <div className="px-6 md:px-10 py-8">
          {/* Seu conteúdo aqui */}
        </div>
      </div>
    </ProtectedRoute>
  )
}
```

## Breadcrumbs Dinâmicos

Para páginas com conteúdo dinâmico (como detalhes de vaga), você pode criar breadcrumbs personalizados:

```tsx
// Exemplo com título dinâmico
const breadcrumbItems = [
  { label: "Candidato", href: "/candidato/dashboard" },
  { label: "Pesquisar Vagas", href: "/candidato/pesquisar-vagas" },
  { label: vaga?.titulo || "Carregando..." }
]

<Breadcrumb items={breadcrumbItems} />
```

## Teste Visual

Após adicionar breadcrumbs, verifique:

1. O breadcrumb aparece no topo da página
2. Os links funcionam corretamente
3. O último item não é clicável (página atual)
4. O espaçamento está correto
5. Responsividade em mobile (texto pode quebrar)

## Próximos Passos

1. Adicione breadcrumbs em TODAS as páginas do candidato listadas acima
2. Faça o mesmo para páginas do empregador (use `empregadorBreadcrumbs`)
3. Faça o mesmo para páginas admin (use `adminBreadcrumbs`)
4. Teste a navegação em todas as páginas
