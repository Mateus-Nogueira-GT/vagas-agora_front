# Guia de Integração - Melhorias do Currículo do Candidato

Este documento descreve como integrar todos os novos componentes no sistema de currículos.

## Componentes Criados

### 1. PhoneInput
**Localização**: `components/form/phone-input.tsx`

**Como usar**:
```tsx
import { PhoneInput } from "@/components/form/phone-input"

// No componente
const [telefone, setTelefone] = useState('')

<PhoneInput
  value={telefone}
  onChange={setTelefone}
  label="Telefone"
  required
/>
```

### 2. LocationSelector
**Localização**: `components/form/location-selector.tsx`

**Como usar**:
```tsx
import { LocationSelector } from "@/components/form/location-selector"

// No componente
const [location, setLocation] = useState({
  cidade: '',
  estado: '',
  cep: '',
  logradouro: '',
  numero: '',
  bairro: '',
  latitude: undefined,
  longitude: undefined
})

<LocationSelector
  value={location}
  onChange={setLocation}
  required
  showCoordinates
/>
```

### 3. AvailabilityRadio
**Localização**: `components/form/availability-radio.tsx`

**Como usar**:
```tsx
import { AvailabilityRadio } from "@/components/form/availability-radio"

// No componente
const [disponibilidade, setDisponibilidade] = useState<'imediato' | 'com_aviso_previo'>('imediato')

<AvailabilityRadio
  value={disponibilidade}
  onChange={setDisponibilidade}
/>
```

### 4. SocialMediaLinks
**Localização**: `components/form/social-media-links.tsx`

**Como usar**:
```tsx
import { SocialMediaLinks } from "@/components/form/social-media-links"

// No componente
const [redesSociais, setRedesSociais] = useState({
  linkedin_url: '',
  github_url: '',
  portfolio_url: '',
  instagram_url: '',
  facebook_url: '',
  youtube_url: ''
})

<SocialMediaLinks
  value={redesSociais}
  onChange={setRedesSociais}
/>
```

### 5. PDFUpload
**Localização**: `components/form/pdf-upload.tsx`

**Como usar**:
```tsx
import { PDFUpload } from "@/components/form/pdf-upload"

// No componente
const [curriculoPdfUrl, setCurriculoPdfUrl] = useState('')
const [curriculoPdfNome, setCurriculoPdfNome] = useState('')

<PDFUpload
  userId={user.id}
  currentPdfUrl={curriculoPdfUrl}
  currentPdfName={curriculoPdfNome}
  onUploadSuccess={(url, fileName) => {
    setCurriculoPdfUrl(url)
    setCurriculoPdfNome(fileName)
  }}
  onRemove={() => {
    setCurriculoPdfUrl('')
    setCurriculoPdfNome('')
  }}
/>
```

### 6. Breadcrumb
**Localização**: `components/breadcrumb.tsx`

**Como usar**:
```tsx
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"

// No topo da página
<Breadcrumb items={candidatoBreadcrumbs.curriculo} />
```

## Integração no app/candidato/curriculo/page.tsx

### Passo 1: Adicionar imports no topo do arquivo

```tsx
// Adicionar aos imports existentes
import { PhoneInput } from "@/components/form/phone-input"
import { LocationSelector } from "@/components/form/location-selector"
import { AvailabilityRadio } from "@/components/form/availability-radio"
import { SocialMediaLinks, SocialMediaData } from "@/components/form/social-media-links"
import { PDFUpload } from "@/components/form/pdf-upload"
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

### Passo 2: Atualizar o formData state

```tsx
// Adicionar ao formData existente
const [formData, setFormData] = useState<Partial<CurriculoFormData>>({
  // ... campos existentes ...

  // Novos campos
  redes_sociais: {
    linkedin_url: '',
    github_url: '',
    portfolio_url: '',
    site_pessoal: '',
    instagram_url: '',
    facebook_url: '',
    youtube_url: ''
  },
  disponibilidade: {
    tipo: 'imediato' as const
  },
  curriculo_pdf_url: '',
  curriculo_pdf_nome: ''
})
```

### Passo 3: Substituir campo de telefone

Encontre o Input atual de telefone e substitua por:

```tsx
<PhoneInput
  value={formData.telefone || ''}
  onChange={(value) => handleInputChange('telefone', value)}
  label="Telefone"
  required
  disabled={!editMode}
/>
```

### Passo 4: Substituir seção de endereço

Encontre os inputs de endereço e substitua por:

```tsx
<LocationSelector
  value={formData.endereco || { cidade: '', estado: '' }}
  onChange={(location) => handleInputChange('endereco', location)}
  required
  disabled={!editMode}
  showCoordinates
/>
```

### Passo 5: Adicionar nova aba "Redes Sociais"

Na lista de TabsTrigger, adicionar:

```tsx
<TabsTrigger value="redes-sociais" className="flex items-center gap-2">
  <Globe className="h-4 w-4" />
  Redes Sociais
</TabsTrigger>
```

E no conteúdo das tabs:

```tsx
<TabsContent value="redes-sociais" ref={sectionRefs["redes-sociais"]}>
  <Card>
    <CardContent className="p-6">
      <SocialMediaLinks
        value={formData.redes_sociais || {}}
        onChange={(data) => handleInputChange('redes_sociais', data)}
        disabled={!editMode}
      />
    </CardContent>
  </Card>
</TabsContent>
```

### Passo 6: Substituir checkboxes de disponibilidade por radio

Encontre a seção de disponibilidade e substitua por:

```tsx
<AvailabilityRadio
  value={formData.disponibilidade?.tipo || 'imediato'}
  onChange={(tipo) => handleInputChange('disponibilidade', { tipo })}
  disabled={!editMode}
/>
```

### Passo 7: Adicionar aba "Currículo PDF"

```tsx
<TabsTrigger value="curriculo-pdf" className="flex items-center gap-2">
  <FileText className="h-4 w-4" />
  Currículo PDF
</TabsTrigger>
```

E no conteúdo:

```tsx
<TabsContent value="curriculo-pdf" ref={sectionRefs["curriculo-pdf"]}>
  <Card>
    <CardContent className="p-6">
      {user?.id && (
        <PDFUpload
          userId={user.id}
          currentPdfUrl={formData.curriculo_pdf_url}
          currentPdfName={formData.curriculo_pdf_nome}
          onUploadSuccess={(url, fileName) => {
            handleInputChange('curriculo_pdf_url', url)
            handleInputChange('curriculo_pdf_nome', fileName)
          }}
          onRemove={() => {
            handleInputChange('curriculo_pdf_url', '')
            handleInputChange('curriculo_pdf_nome', '')
          }}
          disabled={!editMode}
        />
      )}
    </CardContent>
  </Card>
</TabsContent>
```

### Passo 8: Adicionar Breadcrumb no topo

No início do JSX (antes do banner):

```tsx
<div className="px-6 md:px-10 pt-6">
  <Breadcrumb items={candidatoBreadcrumbs.curriculo} />
</div>
```

### Passo 9: Atualizar handleSaveChanges

Certifique-se de que os novos campos sejam salvos:

```tsx
const handleSaveChanges = async () => {
  // ... código existente ...

  const dataToSave = {
    ...formData,
    redes_sociais: formData.redes_sociais,
    disponibilidade: formData.disponibilidade,
    curriculo_pdf_url: formData.curriculo_pdf_url,
    curriculo_pdf_nome: formData.curriculo_pdf_nome
  }

  // Salvar no banco...
}
```

## Busca por Proximidade - pesquisar-vagas/page.tsx

### Imports necessários

```tsx
import { filterVagasByProximity, formatDistance, getUserLocation, RADIUS_OPTIONS } from "@/lib/services/vagas-proximity-service"
import { MapPin, Navigation } from "lucide-react"
import { Breadcrumb, candidatoBreadcrumbs } from "@/components/breadcrumb"
```

### Estado adicional

```tsx
const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null)
const [radiusKm, setRadiusKm] = useState<number>(25)
const [useProximity, setUseProximity] = useState(false)
const [loadingLocation, setLoadingLocation] = useState(false)
```

### Função para obter localização

```tsx
const handleGetLocation = async () => {
  setLoadingLocation(true)
  try {
    const location = await getUserLocation()
    setUserLocation(location)
    setUseProximity(true)
    toast.success('Localização obtida com sucesso!')
  } catch (error: any) {
    toast.error(error.message || 'Erro ao obter localização')
  } finally {
    setLoadingLocation(false)
  }
}
```

### Adicionar filtros de proximidade na UI

```tsx
<div className="flex gap-4 items-end">
  <div className="flex-1">
    <Label>Buscar por proximidade</Label>
    <Button
      variant="outline"
      onClick={handleGetLocation}
      disabled={loadingLocation}
      className="w-full mt-2"
    >
      {loadingLocation ? (
        <Loader2 className="h-4 w-4 animate-spin mr-2" />
      ) : (
        <Navigation className="h-4 w-4 mr-2" />
      )}
      Usar Minha Localização
    </Button>
  </div>

  {useProximity && userLocation && (
    <div className="flex-1">
      <Label>Raio de busca</Label>
      <Select
        value={radiusKm.toString()}
        onValueChange={(val) => setRadiusKm(Number(val))}
      >
        <SelectTrigger>
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {RADIUS_OPTIONS.map((option) => (
            <SelectItem key={option.value} value={option.value.toString()}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )}
</div>
```

### Filtrar vagas por proximidade

```tsx
// Ao carregar vagas
let vagasFiltradas = todasVagas

if (useProximity && userLocation) {
  vagasFiltradas = filterVagasByProximity(vagasFiltradas, userLocation, radiusKm)
}
```

### Exibir distância nos cards

```tsx
{vaga.distance !== undefined && (
  <div className="flex items-center gap-1 text-sm text-gray-600">
    <MapPin className="h-4 w-4" />
    {formatDistance(vaga.distance)}
  </div>
)}
```

## Breadcrumbs em outras páginas

### Dashboard
```tsx
<Breadcrumb items={candidatoBreadcrumbs.dashboard} />
```

### Candidaturas
```tsx
<Breadcrumb items={candidatoBreadcrumbs.candidaturas} />
```

### Configurações
```tsx
<Breadcrumb items={candidatoBreadcrumbs.configuracoes} />
```

### Detalhes da Vaga
```tsx
<Breadcrumb items={candidatoBreadcrumbs.detalhesVaga(vaga.titulo)} />
```

## Checklist de Testes

- [ ] Telefone formata corretamente ao digitar
- [ ] CEP busca endereço automaticamente
- [ ] Seletor de cidade filtra cidades do estado
- [ ] Botão "Buscar Localização" obtém coordenadas
- [ ] Radio buttons de disponibilidade funcionam
- [ ] Redes sociais validam URLs
- [ ] Upload de PDF valida tamanho (10MB) e tipo
- [ ] PDF pode ser visualizado após upload
- [ ] PDF pode ser removido
- [ ] Busca por proximidade filtra vagas
- [ ] Distância é exibida corretamente nos cards
- [ ] Breadcrumbs navegam corretamente
- [ ] Todos os dados são salvos no banco
- [ ] Dados são carregados corretamente ao abrir página

## Notas Importantes

1. **Compatibilidade**: Os campos antigos (`linkedin_url`, `github_url`, etc.) são mantidos para compatibilidade. O novo campo `redes_sociais` JSONB é adicional.

2. **Validação**: Sempre valide dados antes de salvar, especialmente URLs e coordenadas.

3. **Performance**: O serviço de geocoding tem rate limit de 1 req/segundo. Use o sistema de fila incorporado.

4. **Segurança**: PDFs devem ser validados no backend também, não apenas no frontend.

5. **Mobile**: Todos os componentes são responsivos. Teste em diferentes tamanhos de tela.
