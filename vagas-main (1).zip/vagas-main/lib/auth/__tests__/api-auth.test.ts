import { verifyAuth } from '@/lib/auth/api-auth'
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

jest.mock('@supabase/ssr')
jest.mock('next/headers')

describe('verifyAuth', () => {
  beforeEach(() => {
    ;(cookies as jest.Mock).mockResolvedValue({
      get: jest.fn().mockReturnValue({ value: 'mock-cookie' })
    })
  })

  it('deve retornar authorized: false quando não há sessão', async () => {
    const mockGetSession = jest.fn().mockResolvedValue({
      data: { session: null },
      error: null
    })

    ;(createServerClient as jest.Mock).mockReturnValue({
      auth: { getSession: mockGetSession }
    })

    const result = await verifyAuth()

    expect(result.authorized).toBe(false)
    expect(result.user).toBeNull()
    expect(result.error).toBe('Não autenticado')
  })

  it('deve retornar authorized: true com sessão válida', async () => {
    const mockUser = {
      id: 'user-123',
      email: 'test@example.com'
    }

    const mockGetSession = jest.fn().mockResolvedValue({
      data: {
        session: {
          user: mockUser,
          access_token: 'token-123'
        }
      },
      error: null
    })

    ;(createServerClient as jest.Mock).mockReturnValue({
      auth: { getSession: mockGetSession }
    })

    const result = await verifyAuth()

    expect(result.authorized).toBe(true)
    expect(result.user).toEqual(mockUser)
    expect(result.error).toBeNull()
  })
})
