import * as XLSX from 'xlsx'
import { Vaga } from '../vagas/vagas-types'

interface DashboardStats {
  vagas_ativas: number
  total_candidaturas: number
  vagas_preenchidas: number
  taxa_conversao: number
  candidatos_por_vaga: number
  visualizacoes_vagas: number
}

interface CandidaturasTempo {
  date: string
  candidaturas: number
}

interface VagasStatus {
  name: string
  count: number
}

export interface ExportData {
  stats: DashboardStats
  vagas: Vaga[]
  candidaturasTempo: CandidaturasTempo[]
  vagasStatus: VagasStatus[]
  empresaNome: string
}

export function exportDashboardToExcel(data: ExportData) {
  const workbook = XLSX.utils.book_new()

  // Aba 1: Resumo Executivo
  const resumoData = [
    ['RELATÓRIO DE VAGAS - ' + data.empresaNome.toUpperCase()],
    ['Data de Geração:', new Date().toLocaleDateString('pt-BR')],
    [''],
    ['MÉTRICAS PRINCIPAIS'],
    ['Vagas Ativas', data.stats.vagas_ativas],
    ['Total de Candidaturas', data.stats.total_candidaturas],
    ['Vagas Preenchidas', data.stats.vagas_preenchidas],
    ['Taxa de Conversão', data.stats.taxa_conversao + '%'],
    ['Candidatos por Vaga', data.stats.candidatos_por_vaga],
    ['Visualizações Estimadas', data.stats.visualizacoes_vagas],
    [''],
    ['DISTRIBUIÇÃO POR STATUS'],
    ...data.vagasStatus.map(status => [status.name, status.count])
  ]

  const resumoSheet = XLSX.utils.aoa_to_sheet(resumoData)

  // Formatação do cabeçalho
  if (!resumoSheet['!merges']) resumoSheet['!merges'] = []
  resumoSheet['!merges'].push({ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } })

  XLSX.utils.book_append_sheet(workbook, resumoSheet, 'Resumo Executivo')

  // Aba 2: Lista Detalhada de Vagas
  const vagasHeaders = [
    'ID',
    'Título',
    'Status',
    'Cidade',
    'Estado',
    'Modelo de Trabalho',
    'Nível',
    'Tipo de Contratação',
    'Salário De',
    'Salário Até',
    'Total de Candidatos',
    'Data de Publicação',
    'Data de Expiração',
    'Número de Vagas'
  ]

  const vagasData = data.vagas.map(vaga => [
    vaga.id,
    vaga.titulo,
    vaga.status,
    vaga.cidade || '',
    vaga.estado || '',
    vaga.modelo_trabalho || '',
    vaga.nivel || '',
    vaga.tipo_contratacao || '',
    vaga.salario_de || '',
    vaga.salario_ate || '',
    vaga.total_candidatos || 0,
    vaga.data_publicacao ? new Date(vaga.data_publicacao).toLocaleDateString('pt-BR') : '',
    vaga.data_expiracao ? new Date(vaga.data_expiracao).toLocaleDateString('pt-BR') : 'Sem prazo',
    vaga.num_vagas || 1
  ])

  const vagasSheet = XLSX.utils.aoa_to_sheet([vagasHeaders, ...vagasData])

  // Auto-ajustar largura das colunas
  const vagasColWidths = vagasHeaders.map((header, i) => {
    const maxLength = Math.max(
      header.length,
      ...vagasData.map(row => String(row[i] || '').length)
    )
    return { wch: Math.min(maxLength + 2, 50) }
  })
  vagasSheet['!cols'] = vagasColWidths

  XLSX.utils.book_append_sheet(workbook, vagasSheet, 'Vagas Detalhadas')

  // Aba 3: Candidaturas por Período
  const candidaturasHeaders = ['Período', 'Número de Candidaturas']
  const candidaturasData = data.candidaturasTempo.map(item => [
    item.date,
    item.candidaturas
  ])

  const candidaturasSheet = XLSX.utils.aoa_to_sheet([candidaturasHeaders, ...candidaturasData])
  candidaturasSheet['!cols'] = [{ wch: 15 }, { wch: 20 }]

  XLSX.utils.book_append_sheet(workbook, candidaturasSheet, 'Candidaturas por Período')

  // Aba 4: Análise por Localização
  const localizacaoData: Record<string, number> = {}
  const modeloTrabalhoData: Record<string, number> = {}
  const nivelData: Record<string, number> = {}

  data.vagas.forEach(vaga => {
    // Análise por localização
    const localizacao = vaga.cidade && vaga.estado
      ? `${vaga.cidade}, ${vaga.estado}`
      : vaga.cidade || vaga.estado || 'Não informado'
    localizacaoData[localizacao] = (localizacaoData[localizacao] || 0) + 1

    // Análise por modelo de trabalho
    const modelo = vaga.modelo_trabalho || 'Não informado'
    modeloTrabalhoData[modelo] = (modeloTrabalhoData[modelo] || 0) + 1

    // Análise por nível
    const nivel = vaga.nivel || 'Não informado'
    nivelData[nivel] = (nivelData[nivel] || 0) + 1
  })

  const analiseData = [
    ['ANÁLISES POR CATEGORIA'],
    [''],
    ['POR LOCALIZAÇÃO'],
    ...Object.entries(localizacaoData).map(([loc, count]) => [loc, count]),
    [''],
    ['POR MODELO DE TRABALHO'],
    ...Object.entries(modeloTrabalhoData).map(([modelo, count]) => [modelo, count]),
    [''],
    ['POR NÍVEL'],
    ...Object.entries(nivelData).map(([nivel, count]) => [nivel, count])
  ]

  const analiseSheet = XLSX.utils.aoa_to_sheet(analiseData)
  analiseSheet['!cols'] = [{ wch: 25 }, { wch: 15 }]

  XLSX.utils.book_append_sheet(workbook, analiseSheet, 'Análises')

  // Gerar e baixar o arquivo
  const fileName = `relatorio-vagas-${data.empresaNome.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.xlsx`
  XLSX.writeFile(workbook, fileName)

  return fileName
}
