# Ajustes Pendentes nos Filtros de Busca de Vagas

## ✅ Concluído

### 1. Atualização de Níveis de Experiência
- ✅ Função `formatarTexto` atualizada com novos níveis
- ✅ Estado `nivel_experiencia` atualizado no filtro lateral
- ⚠️ **PENDENTE:** Atualizar os checkboxes HTML (linhas 783-850)
- ⚠️ **PENDENTE:** Atualizar lógica de aplicação de filtros

**Novos valores:**
- `estagio` → Estágio / Trainee
- `assistente` → Assistente / Auxiliar
- `operacional` → Operacional
- `analista` → Analista
- `coordenacao` → Coordenação
- `gerencia` → Gerência
- `diretoria` → Diretoria
- `especialista` → Especialista

### 2. Remoção de Vagas Afirmativas
- ✅ Removido do estado `sidebarFilters`
- ⚠️ **PENDENTE:** Remover HTML (linhas 955-1013 aproximadamente)

---

## 🔧 Alterações Pendentes Complexas

### 3. Sistema de Localização: Estado > Cidade

**Problema atual:** Campo de texto livre para localização

**Solução necessária:**

1. **Adicionar novos estados:**
```typescript
const [estadoSelecionado, setEstadoSelecionado] = useState('')
const [cidadeSelecionada, setCidadeSelecionada] = useState('')
const [cidadesDisponiveis, setCidadesDisponiveis] = useState<string[]>([])
```

2. **Criar select de estados** (UF brasileiro):
```tsx
<Select value={estadoSelecionado} onValueChange={handleEstadoChange}>
  <SelectItem value="MG">Minas Gerais</SelectItem>
  <SelectItem value="SP">São Paulo</SelectItem>
  // ... outros estados
</Select>
```

3. **Criar select de cidades** (buscar via API):
```tsx
<Select
  value={cidadeSelecionada}
  onValueChange={handleCidadeChange}
  disabled={!estadoSelecionado}
>
  {cidadesDisponiveis.map(cidade => (
    <SelectItem value={cidade}>{cidade}</SelectItem>
  ))}
</Select>
```

4. **Implementar handlers:**
```typescript
const handleEstadoChange = (estado: string) => {
  setEstadoSelecionado(estado)
  setCidadeSelecionada('') // Limpar cidade quando estado muda
  // Buscar cidades do estado via API
  fetchCidadesPorEstado(estado)
}

const handleCidadeChange = async (cidade: string) => {
  setCidadeSelecionada(cidade)

  // Buscar lat/long da cidade via API de geocoding
  const coords = await fetch(`/api/geocoding?cidade=${cidade}&estado=${estadoSelecionado}`)
  const { latitude, longitude } = await coords.json()

  // Usar para filtrar vagas
  applyLocationFilter(cidade, estadoSelecionado, latitude, longitude)
}
```

5. **API de Geocoding já existe:**
- Endpoint: `/api/geocoding`
- Usar o mesmo serviço usado em currículo e criação de vaga

---

### 4. Ordenação "Mais Próximos"

**Requer:**

1. **Verificar se candidato tem lat/long cadastrado:**
```typescript
const [candidatoTemLocalizacao, setCandidatoTemLocalizacao] = useState(false)

useEffect(() => {
  if (candidato?.endereco?.latitude && candidato?.endereco?.longitude) {
    setCandidatoTemLocalizacao(true)
  }
}, [candidato])
```

2. **Adicionar opção de ordenação (condicional):**
```tsx
<Select value={sortBy} onValueChange={handleSortChange}>
  <SelectItem value="recentes">Mais recentes</SelectItem>
  <SelectItem value="salario-desc">Maior salário</SelectItem>
  <SelectItem value="salario-asc">Menor salário</SelectItem>
  <SelectItem value="relevancia">Relevância</SelectItem>

  {/* Só mostrar se candidato tem localização E não há filtro de cidade ativo */}
  {candidatoTemLocalizacao && !cidadeSelecionada && (
    <SelectItem value="proximidade">Mais próximos</SelectItem>
  )}
</Select>
```

3. **Implementar cálculo de distância (Haversine):**
```typescript
const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371 // Raio da Terra em km
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLon = (lon2 - lon1) * Math.PI / 180
  const a =
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}
```

4. **Adicionar ao sortVagas:**
```typescript
case 'proximidade':
  if (!candidato?.endereco?.latitude || !candidato?.endereco?.longitude) {
    return sorted
  }

  return sorted.sort((a, b) => {
    const distA = a.latitude && a.longitude
      ? calculateDistance(
          candidato.endereco.latitude,
          candidato.endereco.longitude,
          a.latitude,
          a.longitude
        )
      : Infinity

    const distB = b.latitude && b.longitude
      ? calculateDistance(
          candidato.endereco.latitude,
          candidato.endereco.longitude,
          b.latitude,
          b.longitude
        )
      : Infinity

    return distA - distB
  })
```

---

## 📋 Checklist de Implementação

### Ordem Recomendada:

- [ ] 1. Completar remoção de "Vagas Afirmativas" (HTML)
- [ ] 2. Completar atualização de "Níveis de Experiência" (HTML + lógica)
- [ ] 3. Implementar seleção Estado > Cidade
- [ ] 4. Integrar API de geocoding no filtro de localização
- [ ] 5. Implementar ordenação por proximidade
- [ ] 6. Adicionar lógica condicional (mostrar/esconder "Mais próximos")
- [ ] 7. Testar todos os cenários
- [ ] 8. Build final

---

## 🔍 Arquivos Afetados

1. **`app/candidato/pesquisar-vagas/page.tsx`** (principal)
   - Estados dos filtros
   - HTML dos checkboxes
   - Lógica de ordenação
   - Função `applySidebarFilters`

2. **`lib/utils/format-text.ts`** ✅ (já atualizado)

3. **`lib/services/geocoding-service.ts`** (já existe, reutilizar)

4. **`app/api/geocoding/route.ts`** (já existe, reutilizar)

---

## ⚠️ Observações Importantes

1. **Não mostrar "Mais próximos" quando:**
   - Candidato não tem latitude/longitude cadastrada
   - Há filtro de localização (cidade) ativo

2. **Limpar cidade quando estado muda:**
   - Evitar inconsistências

3. **Usar mesma API de geocoding:**
   - Já usada em currículo e criação de vaga
   - Endpoint: `/api/geocoding`

4. **Vagas sem lat/long:**
   - Aparecerão por último na ordenação por proximidade
   - Usar `Infinity` como distância
