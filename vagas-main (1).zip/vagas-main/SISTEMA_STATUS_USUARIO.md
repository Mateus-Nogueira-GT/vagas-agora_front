# Sistema de Verificação de Status do Usuário

## Visão Geral

Este sistema implementa verificação em tempo real do status ativo/inativo dos usuários. Quando um administrador desativa um usuário, o sistema:

1. **Bloqueia o login** de usuários inativos
2. **Detecta em tempo real** quando um usuário é desativado
3. **Notifica o usuário** sobre a desativação
4. **Redireciona** para uma página informativa
5. **Força logout** automático

## Arquivos Criados/Modificados

### Novos Arquivos

#### 1. [app/conta-desativada/page.tsx](app/conta-desativada/page.tsx)
Página exibida quando usuário tenta acessar com conta desativada.
- Layout clean com ícone de alerta
- Botão para contatar administrador
- Botão para voltar ao login
- Limpa localStorage automaticamente

#### 2. [hooks/use-status-check.ts](hooks/use-status-check.ts)
Hook customizado com duas funcionalidades:

**`useStatusCheck(options)`** - Verificação periódica
- Verifica status a cada 30 segundos (configurável)
- Detecta mudança de status em tempo real
- Exibe notificação quando conta é desativada
- Redireciona automaticamente

**`useStatusCheckOnce()`** - Verificação única
- Executa uma vez ao carregar componente
- Útil para verificação inicial

```typescript
// Uso no Sidebar
useStatusCheck({ enabled: !!user, interval: 30000 })
```

#### 3. [app/api/auth/me/route.ts](app/api/auth/me/route.ts)
API endpoint para verificar status do usuário
- Valida token JWT do Supabase
- Retorna dados do usuário incluindo campo `ativo`
- Retorna 401 se token inválido
- Retorna 404 se perfil não encontrado

### Arquivos Modificados

#### 1. [lib/auth/auth-types.ts](lib/auth/auth-types.ts)
Adicionado campo `ativo` à interface User:
```typescript
export interface User {
  id: string
  email: string
  role: 'candidato' | 'empregador' | 'admin'
  nome?: string
  perfil_verificado?: boolean
  ultimo_acesso?: string
  ativo?: boolean  // ← NOVO
}
```

#### 2. [lib/api/auth-api.ts](lib/api/auth-api.ts)
Método `getUserProfile()` atualizado:
- Verifica se `profile.ativo === false`
- Lança erro `CONTA_DESATIVADA` se inativo
- Retorna campo `ativo` no objeto User

#### 3. [lib/auth/auth-service.ts](lib/auth/auth-service.ts)
Método `login()` atualizado:
- Captura erro `CONTA_DESATIVADA`
- Retorna mensagem amigável ao usuário
- Bloqueia login antes de salvar sessão

#### 4. [components/sidebar.tsx](components/sidebar.tsx)
- Importa e usa `useStatusCheck`
- Verifica status a cada 30 segundos enquanto usuário está logado
- Mantém sidebar responsivo durante verificações

## Fluxo de Funcionamento

### 1. Login (Bloqueio Preventivo)
```
Usuário tenta login
    ↓
auth-api.ts: getUserProfile()
    ↓
Verifica profile.ativo
    ↓
Se false → Lança erro "CONTA_DESATIVADA"
    ↓
auth-service.ts: Captura erro
    ↓
Retorna mensagem: "Sua conta está desativada"
    ↓
Login bloqueado
```

### 2. Verificação em Tempo Real
```
Usuário logado no sistema
    ↓
Sidebar carrega → useStatusCheck ativo
    ↓
A cada 30 segundos:
    ├─ Busca token Supabase
    ├─ Chama GET /api/auth/me
    ├─ Verifica campo ativo
    └─ Se false:
        ├─ Exibe toast de erro
        ├─ Faz logout (Supabase)
        ├─ Limpa localStorage
        └─ Redireciona para /conta-desativada
```

### 3. Página de Conta Desativada
```
/conta-desativada
    ↓
Limpa dados de sessão
    ↓
Exibe mensagem informativa
    ↓
Oferece opções:
    ├─ Contatar administrador
    └─ Voltar para login
```

## Configuração

### Intervalo de Verificação

Padrão: **30 segundos**

Para alterar, modifique em [components/sidebar.tsx](components/sidebar.tsx#L46):
```typescript
useStatusCheck({ enabled: !!user, interval: 30000 }) // 30 segundos
```

### Habilitar/Desabilitar

```typescript
// Habilitar apenas se usuário logado
useStatusCheck({ enabled: !!user })

// Desabilitar completamente
useStatusCheck({ enabled: false })
```

## Segurança

### Validações Implementadas

1. **Token JWT** - Validado pelo Supabase em cada requisição
2. **Middleware de API** - Verifica autenticação antes de retornar dados
3. **Logout completo** - Remove sessão Supabase + localStorage
4. **Bloqueio no login** - Previne acesso antes de criar sessão

### Dados Limpos no Logout

- `supabase.auth.signOut()` - Sessão do Supabase
- `localStorage.removeItem('currentUser')` - Dados do usuário
- Cookies de sessão (gerenciados pelo Supabase)

## Testando o Sistema

### 1. Teste de Login Bloqueado

1. Acesse painel admin
2. Desative um usuário (empregador ou candidato)
3. Tente fazer login com esse usuário
4. Deve ver: "Sua conta está desativada. Entre em contato com o administrador."

### 2. Teste de Desativação em Tempo Real

1. Faça login com usuário normal
2. Em outra aba, acesse como admin
3. Desative o usuário da primeira aba
4. Aguarde até 30 segundos
5. Deve ver:
   - Toast: "Sua conta foi desativada pelo administrador"
   - Redirecionamento para `/conta-desativada`

### 3. Teste de Página de Conta Desativada

1. Acesse `/conta-desativada` diretamente
2. Deve ver:
   - Ícone de alerta amarelo
   - Título "Conta Desativada"
   - Mensagem explicativa
   - Botão "Contatar Administrador"
   - Botão "Voltar para Login"

## Melhorias Futuras

### Opcionais (não implementadas)

1. **Realtime do Supabase**
   - Usar `supabase.channel()` para updates instantâneos
   - Reduz latência de 30s para < 1s

2. **Logs de Auditoria**
   - Registrar quando usuário foi bloqueado
   - Timestamp da tentativa de acesso

3. **Notificação por Email**
   - Enviar email quando conta for desativada
   - Link direto para suporte

4. **Mensagem Personalizada**
   - Admin pode adicionar motivo da desativação
   - Exibir na página de conta desativada

## Troubleshooting

### Usuário não é deslogado automaticamente

**Verificar:**
1. Console do navegador - erros de CORS?
2. Token Supabase válido - `await supabase.auth.getSession()`
3. Intervalo configurado - padrão 30s
4. Hook está ativo - `enabled: !!user`

### Erro 401 na API /api/auth/me

**Verificar:**
1. Token está sendo enviado no header
2. Formato: `Authorization: Bearer {token}`
3. Token não expirado - Supabase renova automaticamente

### Usuário consegue fazer login mesmo desativado

**Verificar:**
1. Campo `ativo` existe na tabela `profiles`
2. Valor é `false` (não null ou undefined)
3. Código em `auth-api.ts` verifica corretamente
4. Cache do navegador - limpar e tentar novamente

## Suporte

Para problemas ou dúvidas:
1. Verifique logs do console do navegador
2. Verifique logs da API no terminal
3. Confirme campo `ativo` no banco de dados
4. Teste com usuário diferente
