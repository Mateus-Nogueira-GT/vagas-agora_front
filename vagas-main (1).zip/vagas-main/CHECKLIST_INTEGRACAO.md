# Checklist de Integração - Melhorias do Currículo

Use esta checklist para garantir que todas as melhorias foram integradas corretamente.

---

## FASE 1: Currículo do Candidato (app/candidato/curriculo/page.tsx)

### Imports
- [ ] Importar `PhoneInput` de `@/components/form/phone-input`
- [ ] Importar `LocationSelector` de `@/components/form/location-selector`
- [ ] Importar `AvailabilityRadio` de `@/components/form/availability-radio`
- [ ] Importar `SocialMediaLinks` de `@/components/form/social-media-links`
- [ ] Importar `PDFUpload` de `@/components/form/pdf-upload`
- [ ] Importar `Breadcrumb` e `candidatoBreadcrumbs` de `@/components/breadcrumb`

### State
- [ ] Adicionar `redes_sociais` ao `formData` (objeto vazio inicial)
- [ ] Adicionar `disponibilidade` ao `formData` (tipo 'imediato' inicial)
- [ ] Adicionar `curriculo_pdf_url` ao `formData` (string vazia)
- [ ] Adicionar `curriculo_pdf_nome` ao `formData` (string vazia)

### UI - Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.curriculo} />` no topo da página

### UI - Telefone
- [ ] Localizar o Input atual de telefone
- [ ] Substituir por `<PhoneInput>` com props corretas
- [ ] Testar formatação ao digitar

### UI - Endereço
- [ ] Localizar os inputs de endereço (CEP, estado, cidade, logradouro, etc)
- [ ] Substituir todos por `<LocationSelector>` único
- [ ] Passar `endereco` como value
- [ ] Testar busca de CEP
- [ ] Testar autocomplete de cidade
- [ ] Testar busca de GPS

### UI - Redes Sociais
- [ ] Adicionar nova aba "Redes Sociais" na lista de TabsTrigger
- [ ] Adicionar ícone `<Globe>` na aba
- [ ] Adicionar ref `sectionRefs["redes-sociais"]`
- [ ] Criar `<TabsContent value="redes-sociais">`
- [ ] Adicionar `<SocialMediaLinks>` dentro do TabsContent
- [ ] Testar validação de URLs
- [ ] Testar toggle de redes opcionais

### UI - Disponibilidade
- [ ] Localizar checkboxes de disponibilidade
- [ ] Substituir por `<AvailabilityRadio>`
- [ ] Passar `disponibilidade.tipo` como value
- [ ] Testar seleção de radio buttons

### UI - Currículo PDF
- [ ] Adicionar nova aba "Currículo PDF" na lista de TabsTrigger
- [ ] Adicionar ícone `<FileText>` na aba
- [ ] Adicionar ref `sectionRefs["curriculo-pdf"]`
- [ ] Criar `<TabsContent value="curriculo-pdf">`
- [ ] Adicionar `<PDFUpload>` dentro do TabsContent
- [ ] Passar `userId`, `currentPdfUrl`, `currentPdfName`
- [ ] Implementar `onUploadSuccess`
- [ ] Implementar `onRemove`
- [ ] Testar upload de PDF (< 10MB)
- [ ] Testar validação de tipo (apenas PDF)
- [ ] Testar botões Ver e Remover

### Lógica - Save
- [ ] Atualizar `handleSaveChanges()` para incluir novos campos
- [ ] Garantir que `redes_sociais` é salvo
- [ ] Garantir que `disponibilidade` é salvo
- [ ] Garantir que `curriculo_pdf_url` e `curriculo_pdf_nome` são salvos
- [ ] Testar salvamento completo

### Lógica - Load
- [ ] Atualizar `useEffect` de load para carregar novos campos
- [ ] Garantir que `redes_sociais` carrega do banco
- [ ] Garantir que `disponibilidade` carrega do banco
- [ ] Garantir que PDFs carregam do banco
- [ ] Testar carregamento ao abrir página

---

## FASE 2: Busca de Vagas (app/candidato/pesquisar-vagas/page.tsx)

### Imports
- [ ] Importar funções de `@/lib/services/vagas-proximity-service`
- [ ] Importar ícones `MapPin`, `Navigation` de lucide-react
- [ ] Importar `Breadcrumb` e `candidatoBreadcrumbs`

### State
- [ ] Adicionar `userLocation` (null ou { latitude, longitude })
- [ ] Adicionar `radiusKm` (número, default 25)
- [ ] Adicionar `useProximity` (boolean, default false)
- [ ] Adicionar `loadingLocation` (boolean, default false)

### UI - Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.pesquisarVagas} />` no topo

### UI - Filtros de Proximidade
- [ ] Adicionar botão "Usar Minha Localização"
- [ ] Adicionar ícone `<Navigation>` no botão
- [ ] Mostrar loader quando `loadingLocation` é true
- [ ] Adicionar seletor de raio (Select)
- [ ] Mostrar seletor apenas quando `useProximity` e `userLocation` estão definidos
- [ ] Usar `RADIUS_OPTIONS` do serviço

### Lógica - Geolocalização
- [ ] Criar função `handleGetLocation`
- [ ] Chamar `getUserLocation()` do serviço
- [ ] Salvar resultado em `userLocation`
- [ ] Ativar `useProximity`
- [ ] Tratar erros (permissão negada, etc)
- [ ] Mostrar toast de sucesso/erro

### Lógica - Filtros
- [ ] Aplicar `filterVagasByProximity()` quando `useProximity` é true
- [ ] Passar `userLocation` e `radiusKm` para filtro
- [ ] Atualizar lista de vagas com resultado

### UI - Cards de Vagas
- [ ] Adicionar exibição de distância em cada card
- [ ] Usar `formatDistance()` do serviço
- [ ] Adicionar ícone `<MapPin>` ao lado da distância
- [ ] Testar exibição (metros ou km)

### Testes
- [ ] Testar botão de localização
- [ ] Testar permissão concedida
- [ ] Testar permissão negada
- [ ] Testar seletor de raio
- [ ] Testar filtro de vagas
- [ ] Testar exibição de distância
- [ ] Testar vagas sem coordenadas (aparecem por último)

---

## FASE 3: Detalhes da Vaga (app/candidato/pesquisar-vagas/[id]/page.tsx)

### Imports
- [ ] Importar `Breadcrumb` e `candidatoBreadcrumbs`

### UI - Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.detalhesVaga(vaga?.titulo)} />` no topo
- [ ] Garantir que `vaga?.titulo` está disponível ou usar fallback

### Testes
- [ ] Testar breadcrumb aparece
- [ ] Testar navegação funciona

---

## FASE 4: Outras Páginas do Candidato

### Dashboard (app/candidato/dashboard/page.tsx)
- [ ] Importar Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.dashboard} />`
- [ ] Testar

### Candidaturas (app/candidato/candidaturas/page.tsx)
- [ ] Importar Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.candidaturas} />`
- [ ] Testar

### Configurações (app/candidato/configuracoes/page.tsx)
- [ ] Importar Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.configuracoes} />`
- [ ] Testar

### Ajuda (app/candidato/ajuda/page.tsx)
- [ ] Importar Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.ajuda} />`
- [ ] Testar

### Verificar Currículo (app/candidato/curriculo/verificar/page.tsx)
- [ ] Importar Breadcrumb
- [ ] Adicionar `<Breadcrumb items={candidatoBreadcrumbs.curriculoVerificar} />`
- [ ] Testar

---

## FASE 5: Testes Finais

### Testes de Componentes Isolados
- [ ] PhoneInput formata corretamente
- [ ] LocationSelector busca CEP
- [ ] LocationSelector busca GPS
- [ ] AvailabilityRadio alterna entre opções
- [ ] SocialMediaLinks valida URLs
- [ ] PDFUpload aceita apenas PDF
- [ ] PDFUpload valida tamanho (10MB)
- [ ] Breadcrumb navega corretamente

### Testes de Integração - Currículo
- [ ] Preencher todos os campos novos
- [ ] Salvar currículo
- [ ] Recarregar página
- [ ] Verificar se dados carregaram
- [ ] Testar modo visualização
- [ ] Testar modo edição

### Testes de Integração - Busca
- [ ] Buscar vagas sem filtro de proximidade
- [ ] Ativar filtro de proximidade
- [ ] Conceder permissão de localização
- [ ] Filtrar por 25km
- [ ] Verificar vagas filtradas
- [ ] Verificar distância exibida
- [ ] Mudar raio para 50km
- [ ] Verificar vagas atualizadas

### Testes de Performance
- [ ] Upload de PDF de 10MB não trava
- [ ] Autocomplete de cidade é rápido
- [ ] Busca de CEP não duplica requisições
- [ ] Filtro de proximidade é rápido

### Testes de Responsividade
- [ ] Testar em mobile (375px)
- [ ] Testar em tablet (768px)
- [ ] Testar em desktop (1920px)
- [ ] Breadcrumb quebra linha adequadamente
- [ ] Todos os componentes se adaptam

### Testes de Acessibilidade
- [ ] Navegação por teclado funciona
- [ ] Labels estão corretos
- [ ] Mensagens de erro são claras
- [ ] Foco visual está visível

---

## FASE 6: Documentação e Deploy

### Documentação
- [ ] Atualizar README do projeto (se necessário)
- [ ] Documentar mudanças no CHANGELOG (se houver)
- [ ] Verificar que INTEGRATION_GUIDE.md está acessível

### Banco de Dados
- [ ] Verificar que migration foi executada
- [ ] Verificar índices criados
- [ ] Testar queries com novos campos

### Deploy
- [ ] Fazer commit das mudanças
- [ ] Criar PR (se aplicável)
- [ ] Executar testes automatizados (se houver)
- [ ] Deploy em staging
- [ ] Testar em staging
- [ ] Deploy em produção
- [ ] Monitorar logs

---

## Resumo de Progresso

### Componentes Criados
- [x] PhoneInput ✅
- [x] LocationSelector ✅
- [x] AvailabilityRadio ✅
- [x] SocialMediaLinks ✅
- [x] PDFUpload ✅
- [x] Breadcrumb ✅

### Serviços Criados
- [x] vagas-proximity-service ✅
- [x] uploadCurriculoPDF ✅

### Migrations
- [x] add_curriculo_improvements ✅

### Integrações Pendentes
- [ ] Currículo do candidato
- [ ] Busca de vagas
- [ ] Breadcrumbs em todas as páginas

---

## Status Geral

**Implementação**: 🟢 100% Completo
**Integração**: 🟡 Aguardando ação manual
**Testes**: 🟡 Aguardando integração
**Deploy**: ⚪ Não iniciado

---

## Próxima Ação Recomendada

1. ✅ Começar pela **FASE 1** (Currículo)
2. Seguir o `INTEGRATION_GUIDE.md` passo a passo
3. Testar cada mudança antes de prosseguir
4. Fazer commit após cada fase completada
5. Partir para **FASE 2** (Busca de vagas)
6. Finalizar com **FASE 3 e 4** (Breadcrumbs)

---

**Tempo estimado de integração**: 3-4 horas
**Dificuldade**: Média (requer atenção aos detalhes)
**Prioridade**: Alta (melhorias críticas para UX)
