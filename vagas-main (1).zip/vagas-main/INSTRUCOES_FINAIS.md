# Instruções Finais - Filtros de Busca

## ✅ O que já está funcionando:

1. **`formatarTexto`** corrigido - sem duplicação de `estagio`
2. **Cards de vagas** aplicando formatação correta
3. **Estado dos filtros** atualizado com novos níveis
4. **Vagas afirmativas** removidas
5. **Documentos adicionais** removidos

---

## 🔧 O que VOCÊ precisa fazer agora:

### PASSO 1: Atualizar HTML dos Checkboxes

**Arquivo:** `app/candidato/pesquisar-vagas/page.tsx`
**Linha aproximada:** 783-850

**Procurar por:**
```tsx
{/* Nível de experiência */}
<div>
  <Label className="text-sm text-gray-600 mb-2 block">Nível de experiência</Label>
```

**Código completo para substituir:** Ver arquivo `CODIGO_CHECKBOXES_NIVEL.md`

---

### PASSO 2: Atualizar função `applySidebarFilters`

**Arquivo:** `app/candidato/pesquisar-vagas/page.tsx`

**Procurar a função `applySidebarFilters` e atualizar a parte de níveis:**

**DE:**
```typescript
// Filtrar por nível de experiência
if (Object.values(sidebarFilters.nivel_experiencia).some(v => v)) {
  const niveisAtivos = Object.entries(sidebarFilters.nivel_experiencia)
    .filter(([_, ativo]) => ativo)
    .map(([nivel, _]) => nivel)

  newFilters.nivel = niveisAtivos // ❌ Pode estar assim
}
```

**PARA:**
```typescript
// Filtrar por nível de experiência
if (Object.values(sidebarFilters.nivel_experiencia).some(v => v)) {
  const niveisAtivos = Object.entries(sidebarFilters.nivel_experiencia)
    .filter(([_, ativo]) => ativo)
    .map(([nivel, _]) => nivel)

  if (niveisAtivos.length > 0) {
    newFilters.nivel = niveisAtivos.join(',')
  }
}
```

---

### PASSO 3: Remover Quick Filters antigos

**Arquivo:** `app/candidato/pesquisar-vagas/page.tsx`
**Linha aproximada:** 49-56

**DE:**
```typescript
const [quickFilters, setQuickFilters] = useState({
  remoto: false,
  clt: false,
  publicadas_hoje: false,
  junior: false,   // ❌ REMOVER
  pleno: false,    // ❌ REMOVER
  senior: false    // ❌ REMOVER
})
```

**PARA:**
```typescript
const [quickFilters, setQuickFilters] = useState({
  remoto: false,
  clt: false,
  publicadas_hoje: false
})
```

---

### PASSO 4: Atualizar funções relacionadas a quick filters

**Procurar e REMOVER referências a `junior`, `pleno`, `senior` nas funções:**

1. **`toggleQuickFilter`** - Remover cases de junior/pleno/senior
2. **`removeActiveFilter`** - Remover cases de Júnior/Pleno/Sênior
3. **`applyQuickFilters`** - Remover lógica desses níveis

**Exemplo em `removeActiveFilter`:**

**DE:**
```typescript
switch (filterLabel) {
  case 'Remoto':
    newQuickFilters.remoto = false
    break
  case 'CLT':
    newQuickFilters.clt = false
    break
  case 'Júnior':    // ❌ REMOVER
    newQuickFilters.junior = false
    break
  case 'Pleno':     // ❌ REMOVER
    newQuickFilters.pleno = false
    break
  case 'Sênior':    // ❌ REMOVER
    newQuickFilters.senior = false
    break
}
```

**PARA:**
```typescript
switch (filterLabel) {
  case 'Remoto':
    newQuickFilters.remoto = false
    break
  case 'CLT':
    newQuickFilters.clt = false
    break
  case 'Publicadas hoje':
    newQuickFilters.publicadas_hoje = false
    break
}
```

---

### PASSO 5: Limpar build e testar

```bash
# Windows (PowerShell)
Remove-Item -Recurse -Force .next
npm run build

# Linux/Mac
rm -rf .next
npm run build
```

---

## 🎯 Níveis Corretos do Sistema

Esses são os valores que o empregador escolhe ao criar vaga:

| Valor no BD      | Label exibido           |
|------------------|-------------------------|
| `estagio`        | Estágio / Trainee       |
| `assistente`     | Assistente / Auxiliar   |
| `operacional`    | Operacional             |
| `analista`       | Analista                |
| `coordenacao`    | Coordenação             |
| `gerencia`       | Gerência                |
| `diretoria`      | Diretoria               |
| `especialista`   | Especialista            |

---

## ⚠️ IMPORTANTE

- **NÃO** use mais `junior`, `pleno`, `senior`, `estagiario`, `trainee` nos filtros
- Esses valores antigos estão mantidos apenas para **compatibilidade com dados antigos**
- Todos os novos filtros devem usar os 8 níveis listados acima

---

## 📝 Checklist Rápido

- [ ] Copiar código de `CODIGO_CHECKBOXES_NIVEL.md` para `pesquisar-vagas/page.tsx`
- [ ] Atualizar função `applySidebarFilters`
- [ ] Remover quick filters antigos (junior/pleno/senior)
- [ ] Atualizar funções `toggleQuickFilter`, `removeActiveFilter`, `applyQuickFilters`
- [ ] Deletar pasta `.next`
- [ ] Rodar `npm run build`
- [ ] Testar filtros no navegador

---

**Pronto!** Depois dessas alterações os filtros estarão 100% alinhados com o cadastro de vagas.
